import { useState ,useEffect} from 'react';

import { Link } from 'react-router-dom';
import { formatDate } from '../lib/formatters';
import { useDeleteJob, useUpdateJob } from '../lib/graphql/hooks';


function JobList({ jobs }) {
  return (
    <ul className="box">
      {jobs.map((job) => (
        <JobItem key={job.id} job={job} />
      ))}
    </ul>
  );
}

function JobItem({ job }) {
  const { deleteJob, loading,data } = useDeleteJob();
  const [formdata,setFormData ]= useState({date:"",name:""});
  const [update,setUpdate]=useState(false)
  const { updateJob, loading1,data1 } = useUpdateJob();
  const title = job.company
    ? `${job.title} at ${job.company.name}`
    : job.title;
    console.log(data,'dattttttttttttt')
    useEffect(() => {
    
        setFormData({ date: formatDate(job.date), name: title });
      
    }, [job,title, setFormData]);
    if(data){
      return <div>Job deleted successfully</div>
    }
   
    const handleChange=(e)=>{
      setFormData({...formdata,[e.target.name]:e.target.value})
      setUpdate(true)
    }
    const handleUpdate=()=>{
      updateJob(job.id, formdata)
      .then(() => {
        // Handle successful update, if needed
        console.log('Job updated successfully');
        setUpdate(false); // Reset update state after successful update
      })
      .catch((error) => {
        // Handle error during update, if needed
        console.error('Error updating job:', error);
      });
    }
  return (
    <li className="media">
      <div className="media-left has-text-grey">
        {formatDate(job.date)}
      </div>
      <div className="media-content">
        <Link to={`/jobs/${job.id}`}>
          {title}
        </Link>
        <button onClick={()=>deleteJob(job.id)}>delete</button>
        <button  onClick={()=>setUpdate(true)} >UPDATE</button>

      </div>
      {update&&<><input value={formdata.date} name="date" onChange={handleChange}/>
      <input value={formdata.name} onChange={handleChange} name="name"/>
      
      <button onClick={()=>handleUpdate()}>update</button></>}
    </li>
  );
}

export default JobList;
